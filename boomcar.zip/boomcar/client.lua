RegisterNetEvent('boomcar:explodeVehicles', function(radius)
    local playerPed = PlayerPedId()
    local playerCoords = GetEntityCoords(playerPed)
    local vehicles = GetVehiclesInRadius(playerCoords, radius)

    for _, vehicle in ipairs(vehicles) do
        NetworkRequestControlOfEntity(vehicle)
        SetVehicleExplodesOnHighExplosionDamage(vehicle, true)
        AddExplosion(GetEntityCoords(vehicle), 2, 10.0, true, false, 1.0)
    end

    TriggerEvent('QBCore:Notify', '指定された範囲内の車両を爆破しました。', 'success')
end)

function GetVehiclesInRadius(coords, radius)
    local vehicles = {}
    local handle, vehicle = FindFirstVehicle()
    local success
    repeat
        local vehicleCoords = GetEntityCoords(vehicle)
        if #(coords - vehicleCoords) <= radius then
            table.insert(vehicles, vehicle)
        end
        success, vehicle = FindNextVehicle(handle)
    until not success
    EndFindVehicle(handle)
    return vehicles
end
