QBCore = exports['qb-core']:GetCoreObject()

-- コマンド 'boomcar' を登録
QBCore.Commands.Add('boomcar', '指定範囲内の車両を爆破する (Gods Job Only)', 
    {{name = 'radius', help = '爆破する範囲の半径'}}, false, function(source, args)
    local Player = QBCore.Functions.GetPlayer(source)
    local radius = tonumber(args[1])

    -- 'gods' ジョブのプレイヤーのみ実行可能
    if Player and Player.PlayerData.job.name == "gods" then
        if radius and radius > 0 then
            TriggerClientEvent('boomcar:explodeVehicles', source, radius)
            TriggerClientEvent('QBCore:Notify', source, '車両を爆破しました。', 'success', 5000)
        else
            TriggerClientEvent('QBCore:Notify', source, '正しい半径を入力してください。', 'error', 5000)
        end
    else
        TriggerClientEvent('QBCore:Notify', source, 'このコマンドを使用する権限がありません。', 'error', 5000)
    end
end)
